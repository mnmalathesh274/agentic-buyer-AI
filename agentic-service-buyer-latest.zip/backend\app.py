import json
import os
import random
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


ROOT_DIR = Path(__file__).resolve().parent.parent
STORAGE_PATH = Path(__file__).resolve().parent / "storage.json"
HOST = "127.0.0.1"
PORT = 8000

DEFAULT_STATE = {
    "daily_cap": 40,
    "monthly_cap": 120,
    "spent_daily": 0,
    "spent_monthly": 0,
    "receipts": [],
}

SERVICES = [
    {
        "id": "weather-oracle",
        "name": "Weather Oracle API",
        "description": "Localized planning data for routing, field ops, and purchase timing agents.",
        "price": 12,
        "category": "Data feed",
        "payment_address": "TESTNET-WTHR-4TBM-01A2",
        "response_preview": "Forecast confidence 94%, precipitation risk low, wind volatility moderate.",
        "latency_target": "2.1s avg",
        "settlement_mode": "ALGO transfer",
    },
    {
        "id": "identity-check",
        "name": "Identity Check Gateway",
        "description": "KYC and risk screening for high-value autonomous workflows.",
        "price": 18,
        "category": "Compliance",
        "payment_address": "TESTNET-KYC0-X18A-88PQ",
        "response_preview": "Counterparty verified with medium-risk jurisdiction advisory.",
        "latency_target": "3.4s avg",
        "settlement_mode": "ALGO transfer",
    },
    {
        "id": "route-engine",
        "name": "Route Engine",
        "description": "Optimization service for logistics agents and delivery decision loops.",
        "price": 9,
        "category": "Compute",
        "payment_address": "TESTNET-ROUT-E7A3-29LQ",
        "response_preview": "Optimal route reduced travel cost estimate by 11%.",
        "latency_target": "1.8s avg",
        "settlement_mode": "ASA-ready",
    },
    {
        "id": "market-signal",
        "name": "Market Signal Stream",
        "description": "Short-horizon pricing and sentiment intelligence for trading copilots.",
        "price": 15,
        "category": "Signal",
        "payment_address": "TESTNET-MRKT-71EZ-305Q",
        "response_preview": "Momentum positive across 3 tracked sectors with moderate confidence.",
        "latency_target": "2.8s avg",
        "settlement_mode": "ALGO transfer",
    },
]


def load_env_file() -> None:
    env_path = ROOT_DIR / ".env"
    if not env_path.exists():
        return

    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue

        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def load_state() -> dict[str, Any]:
    if not STORAGE_PATH.exists():
        save_state(DEFAULT_STATE)
        return clone_default_state()

    try:
        data = json.loads(STORAGE_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return clone_default_state()

    return {
        "daily_cap": int(data.get("daily_cap", data.get("spend_cap", DEFAULT_STATE["daily_cap"]))),
        "monthly_cap": int(data.get("monthly_cap", DEFAULT_STATE["monthly_cap"])),
        "spent_daily": int(data.get("spent_daily", data.get("spent", 0))),
        "spent_monthly": int(data.get("spent_monthly", data.get("spent", 0))),
        "receipts": list(data.get("receipts", [])),
    }


def save_state(state: dict[str, Any]) -> None:
    STORAGE_PATH.write_text(json.dumps(state, indent=2), encoding="utf-8")


def clone_default_state() -> dict[str, Any]:
    return {
        "daily_cap": DEFAULT_STATE["daily_cap"],
        "monthly_cap": DEFAULT_STATE["monthly_cap"],
        "spent_daily": DEFAULT_STATE["spent_daily"],
        "spent_monthly": DEFAULT_STATE["spent_monthly"],
        "receipts": [],
    }


def build_config() -> dict[str, Any]:
    gemini_key = os.getenv("GEMINI_API_KEY", "").strip()
    return {
        "network": os.getenv("ALGOD_NETWORK", "testnet"),
        "algod_server": os.getenv("ALGOD_SERVER", "https://testnet-api.algonode.cloud"),
        "indexer_server": os.getenv("INDEXER_SERVER", "https://testnet-idx.algonode.cloud"),
        "payment_wallet": os.getenv("PAYMENT_WALLET", "TESTNET-AGENT-BUYER-WALLET-001"),
        "pinata_gateway": os.getenv("PINATA_GATEWAY", "https://gateway.pinata.cloud/ipfs"),
        "gemini_enabled": bool(gemini_key),
        "gemini_model": os.getenv("GEMINI_MODEL", "gemini-1.5-flash"),
    }


def find_service(service_id: str) -> dict[str, Any] | None:
    return next((service for service in SERVICES if service["id"] == service_id), None)


def generate_tx_id() -> str:
    tail = str(int(time.time() * 1000))[-6:]
    random_part = "".join(random.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(6))
    return f"ALGO-{random_part}-{tail}"


def purchase_tag(service: dict[str, Any], objective: str) -> str:
    compact_goal = objective.strip()[:52] if objective else "default-fulfillment"
    return f"svc={service['id']}|price={service['price']}|goal={compact_goal}"


def build_receipt(service: dict[str, Any], status: str, tx_id: str, response: str) -> dict[str, Any]:
    return {
        "service_name": service["name"],
        "cost": service["price"],
        "tx_id": tx_id,
        "status": status,
        "response": response,
        "explorer_url": (
            f"https://testnet.algoexplorer.io/tx/{tx_id}"
            if status == "Confirmed" and tx_id != "REJECTED-BY-POLICY"
            else ""
        ),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def generate_brief(objective: str, service: dict[str, Any] | None) -> str:
    objective = objective.strip()
    if not objective:
        return "Provide an objective so the buyer agent can prepare a purchase brief."

    service_context = (
        f"Target service: {service['name']} ({service['category']}, {service['price']} ALGO). "
        if service
        else "Target service: any matching registry listing. "
    )
    prompt = (
        "You are drafting a machine-readable purchase brief for an autonomous service buyer on Algorand. "
        "Return a concise operator-friendly paragraph followed by a compact intent tag. "
        f"{service_context}"
        f"Objective: {objective}"
    )

    gemini_key = os.getenv("GEMINI_API_KEY", "").strip()
    gemini_model = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")

    if not gemini_key:
        return (
            f"Buyer brief: Acquire a service that satisfies '{objective}' while respecting spend caps, "
            "waiting for on-chain confirmation, and logging the receipt for audit. "
            f"Intent tag: objective={objective[:40]} | service={service['id'] if service else 'auto-select'} | mode=policy-checked."
        )

    endpoint = (
        f"https://generativelanguage.googleapis.com/v1beta/models/{gemini_model}:generateContent"
        f"?key={gemini_key}"
    )
    body = json.dumps(
        {
            "contents": [
                {
                    "parts": [
                        {
                            "text": prompt,
                        }
                    ]
                }
            ]
        }
    ).encode("utf-8")

    request = urllib.request.Request(
        endpoint,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as exc:
        return f"Gemini request failed, so a local fallback brief was used instead. Details: {exc}"

    candidates = payload.get("candidates", [])
    if not candidates:
        return "Gemini returned no candidates. Check the API key, model name, or quota."

    parts = candidates[0].get("content", {}).get("parts", [])
    texts = [part.get("text", "").strip() for part in parts if part.get("text")]
    return "\n".join(texts) if texts else "Gemini returned an empty completion."


class Handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self._send_common_headers()
        self.end_headers()

    def do_GET(self) -> None:
        if self.path == "/api/config":
            self._send_json(200, build_config())
            return

        if self.path == "/api/services":
            self._send_json(200, {"services": SERVICES})
            return

        if self.path == "/api/state":
            self._send_json(200, load_state())
            return

        self._serve_static()

    def do_POST(self) -> None:
        if self.path == "/api/policy":
            self._handle_policy()
            return

        if self.path == "/api/purchase":
            self._handle_purchase()
            return

        if self.path == "/api/receipts/clear":
            self._handle_clear_receipts()
            return

        if self.path == "/api/gemini/brief":
            self._handle_gemini_brief()
            return

        self._send_json(404, {"error": "Route not found."})

    def _handle_policy(self) -> None:
        payload = self._read_json_body()
        try:
            daily_cap = int(payload.get("daily_cap", 0))
            monthly_cap = int(payload.get("monthly_cap", 0))
        except (TypeError, ValueError):
            daily_cap = 0
            monthly_cap = 0
        if daily_cap <= 0 or monthly_cap <= 0 or monthly_cap < daily_cap:
            self._send_json(400, {"error": "Daily and monthly caps must be positive, and monthly must be at least daily."})
            return

        state = load_state()
        state["daily_cap"] = daily_cap
        state["monthly_cap"] = monthly_cap
        save_state(state)
        self._send_json(
            200,
            {
                "message": f"Spend policy saved with daily cap {daily_cap} ALGO and monthly cap {monthly_cap} ALGO.",
                "state": state,
            },
        )

    def _handle_purchase(self) -> None:
        payload = self._read_json_body()
        service = find_service(str(payload.get("service_id", "")))
        if not service:
            self._send_json(404, {"error": "Service not found in the registry."})
            return

        state = load_state()
        projected_daily = state["spent_daily"] + service["price"]
        projected_monthly = state["spent_monthly"] + service["price"]

        if projected_daily > state["daily_cap"] or projected_monthly > state["monthly_cap"]:
            receipt = build_receipt(
                service=service,
                status="Rejected",
                tx_id="REJECTED-BY-POLICY",
                response="Policy engine blocked purchase before payment.",
            )
            state["receipts"].insert(0, receipt)
            save_state(state)
            self._send_json(
                200,
                {
                    "state": state,
                    "summary": {
                        "title": "Purchase blocked by policy",
                        "copy": (
                            f"{service['name']} would push usage to {projected_daily}/{projected_monthly} ALGO, "
                            f"beyond the active policy limits of {state['daily_cap']}/{state['monthly_cap']} ALGO."
                        ),
                        "tone": "blocked",
                    },
                    "timeline": [
                        {"step": "Discover", "detail": f"Selected {service['name']} from the registry."},
                        {
                            "step": "Policy",
                            "detail": (
                                f"Rejected before payment because projected daily/monthly totals "
                                f"{projected_daily}/{projected_monthly} ALGO exceed policy "
                                f"{state['daily_cap']}/{state['monthly_cap']} ALGO."
                            ),
                        },
                    ],
                },
            )
            return

        tx_id = generate_tx_id()
        objective = str(payload.get("objective", "")).strip()
        tag = purchase_tag(service, objective)

        receipt = build_receipt(
            service=service,
            status="Confirmed",
            tx_id=tx_id,
            response=service["response_preview"],
        )
        state["spent_daily"] = projected_daily
        state["spent_monthly"] = projected_monthly
        state["receipts"].insert(0, receipt)
        save_state(state)

        self._send_json(
            200,
            {
                "state": state,
                "summary": {
                    "title": "Transaction confirmed",
                    "copy": (
                        f"{service['name']} cleared the policy check, confirmed on-chain, "
                        "and the receipt was persisted."
                    ),
                    "tone": "active",
                },
                "timeline": [
                    {"step": "Discover", "detail": f"Located {service['name']} at {service['payment_address']}."},
                    {
                        "step": "Policy",
                        "detail": (
                            f"Spend check passed. Projected daily/monthly totals "
                            f"{projected_daily}/{projected_monthly} ALGO remain within "
                            f"{state['daily_cap']}/{state['monthly_cap']} ALGO."
                        ),
                    },
                    {"step": "Pay", "detail": f"Created transaction {tx_id} with note tag '{tag}'."},
                    {"step": "Confirm", "detail": "Simulated on-chain confirmation succeeded for the payment transaction."},
                    {"step": "Consume", "detail": f"Service response received: {service['response_preview']}"},
                    {"step": "Log", "detail": "Receipt written to persistent storage and spend totals updated."},
                ],
            },
        )

    def _handle_clear_receipts(self) -> None:
        state = clone_default_state()
        save_state(state)
        self._send_json(
            200,
            {
                "message": "Receipt log cleared and spend totals reset.",
                "state": state,
            },
        )

    def _handle_gemini_brief(self) -> None:
        payload = self._read_json_body()
        objective = str(payload.get("objective", ""))
        service = find_service(str(payload.get("service_id", ""))) if payload.get("service_id") else None
        brief = generate_brief(objective, service)
        self._send_json(200, {"brief": brief})

    def _serve_static(self) -> None:
        path = self.path
        if path in ("/", ""):
            target = ROOT_DIR / "index.html"
        else:
            target = (ROOT_DIR / path.lstrip("/")).resolve()

        if not str(target).startswith(str(ROOT_DIR.resolve())) or not target.exists() or not target.is_file():
            self._send_json(404, {"error": "Static file not found."})
            return

        content_type = "text/plain; charset=utf-8"
        if target.suffix == ".html":
            content_type = "text/html; charset=utf-8"
        elif target.suffix == ".css":
            content_type = "text/css; charset=utf-8"
        elif target.suffix == ".js":
            content_type = "application/javascript; charset=utf-8"

        self.send_response(200)
        self._send_common_headers(content_type)
        self.end_headers()
        self.wfile.write(target.read_bytes())

    def _read_json_body(self) -> dict[str, Any]:
        content_length = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(content_length) if content_length else b"{}"
        try:
            return json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError:
            return {}

    def _send_json(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self._send_common_headers("application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(body)

    def _send_common_headers(self, content_type: str = "application/json; charset=utf-8") -> None:
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")


def main() -> None:
    load_env_file()
    save_state(load_state())
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"Serving Agentic Service Buyer on http://{HOST}:{PORT}")
    server.serve_forever()


if __name__ == "__main__":
    main()
